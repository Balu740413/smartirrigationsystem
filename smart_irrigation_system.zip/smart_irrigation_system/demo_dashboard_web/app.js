// Simulated sensor data and AI inference for Smart Irrigation System
// Mirrors the ESP32-S3 firmware logic for demonstration

class IrrigationSimulator {
  constructor() {
    this.moisture = 65;           // 0-100%
    this.ec = 1.2;                // mS/cm (0-3.0)
    this.soilTemp = 24.5;         // °C
    this.airTemp = 22.0;          // °C
    this.humidity = 65;           // %
    this.light = 70;              // 0-100%
    this.tankLevel = 95;          // 0-100%
    this.pumpActive = false;
    this.totalIrrigationMs = 0;
    this.cycleStartTime = null;
    this.lastUpdateTime = new Date();

    this.healthHistory = [];
    this.moistureHistory = [];
    this.eventLog = [];
    this.moistureThresholdLow = 45;
    this.moistureThresholdHigh = 75;

    this.addEvent("System initialized");
    this.addEvent("Sensor simulation enabled");
    this.addEvent("AI processor ready");
  }

  // Simulate realistic soil and environmental changes
  update() {
    const now = new Date();
    const deltaMs = now - this.lastUpdateTime;
    const deltaSec = deltaMs / 1000;
    this.lastUpdateTime = now;

    // Daily cycle simulation (accelerated - 1 simulation hour = 10 real seconds)
    const hour = (now.getHours() + now.getMinutes() / 60 + now.getSeconds() / 3600) * 6; // Accelerated
    const dayProgress = (hour % 24) / 24;

    // Temperature cycle: warmest at noon, coolest at midnight
    this.airTemp = 18 + 10 * Math.sin(Math.PI * dayProgress);
    this.soilTemp = this.airTemp + 2; // Soil warmer than air
    this.humidity = 70 - 20 * Math.sin(Math.PI * dayProgress); // Inverse to temp
    this.light = Math.max(0, 100 * Math.sin(Math.PI * (hour - 6) / 12)); // Peak at noon

    // Moisture decreases due to evapotranspiration
    const evaporation = (0.5 + this.light / 50) * deltaSec / 10; // More evap during day
    this.moisture -= evaporation;

    // Stop pump if reaching high threshold
    if (this.pumpActive && this.moisture >= this.moistureThresholdHigh) {
      this.stopPump();
    }

    // Start pump if below low threshold
    if (!this.pumpActive && this.moisture < this.moistureThresholdLow) {
      this.startPump();
    }

    // Pump adds moisture when active
    if (this.pumpActive) {
      const waterAddition = 0.5 * deltaSec / 10; // Add moisture while watering
      this.moisture += waterAddition;
      this.tankLevel -= waterAddition * 0.5; // Tank depletes
    }

    // Clamp values to realistic ranges
    this.moisture = Math.max(20, Math.min(95, this.moisture));
    this.ec = 1.2 + (Math.random() - 0.5) * 0.3; // EC fluctuates
    this.tankLevel = Math.max(0, this.tankLevel);

    // Update moisture and EC history
    this.moistureHistory.push(this.moisture);
    if (this.moistureHistory.length > 100) {
      this.moistureHistory.shift();
    }

    // Refill tank slowly if below 20%
    if (this.tankLevel < 20) {
      this.tankLevel += 0.1 * deltaSec;
    }
  }

  startPump() {
    this.pumpActive = true;
    this.cycleStartTime = new Date();
    this.addEvent("Pump ACTIVATED - Watering cycle started");
  }

  stopPump() {
    if (this.pumpActive) {
      const duration = Math.round((new Date() - this.cycleStartTime) / 1000);
      this.pumpActive = false;
      this.totalIrrigationMs += duration * 1000;
      this.addEvent(`Pump DEACTIVATED - Duration: ${duration}s`);
    }
  }

  // AI soil health classification - uses ML model if available
  async classifyHealth() {
    // Build feature vector (18 features as per train_soil_health_model.py)
    // Features 0-7: Raw sensor values (normalized to match training)
    const moisture_norm = this.moisture / 100.0;  // 0-1
    const ec_norm = this.ec / 3.5;  // 0-1 (max EC is 3.5)
    const soil_temp_norm = this.soilTemp / 50.0;  // 0-1 (max temp is 50°C)
    const air_temp_norm = this.airTemp / 50.0;  // 0-1
    const humidity_norm = this.humidity / 100.0;  // 0-1
    const light_norm = this.light / 100.0;  // 0-1
    const tank_norm = this.tankLevel / 100.0;  // 0-1
    
    // Health score (feature 7): inverse of stress, normalized 0-1
    const base_stress = (this.moisture < 45 ? 0.6 : (this.moisture < 60 ? 0.3 : 0.1));
    const health_score = 1.0 - base_stress;
    
    // Features 8-12: Rolling averages and trends
    const moisture_avg = moisture_norm;  // Simplified: use current as avg
    const ec_avg = ec_norm;  // Simplified: use current as avg
    const temp_avg = soil_temp_norm;  // Simplified: use current as avg
    const moisture_trend = 0.0;  // Could calculate from moistureHistory
    const ec_trend = 0.0;  // Could calculate from history
    
    // Features 13-17: Stress indicators (5 values, normalized 0-1)
    const drought_stress = Math.max(0, Math.min(1, (this.moisture < 45) ? (45 - this.moisture) / 45.0 : 0.0));
    const waterlogging_stress = Math.max(0, Math.min(1, (this.moisture > 85) ? (this.moisture - 85) / 15.0 : 0.0));
    const nutrient_stress = Math.max(0, Math.min(1, (this.ec < 0.8 || this.ec > 2.0) ? Math.abs(this.ec - 1.4) / 1.4 : 0.0));
    const temp_stress = Math.max(0, Math.min(1, (this.soilTemp < 15 || this.soilTemp > 30) ? Math.abs(this.soilTemp - 22.5) / 22.5 : 0.0));
    const light_stress = Math.max(0, Math.min(1, (this.light < 20) ? (20 - this.light) / 20.0 : 0.0));
    
    const features = [
      moisture_norm,      // 0: moisture / 100
      ec_norm,            // 1: ec / 3.5
      soil_temp_norm,     // 2: soilTemp / 50
      air_temp_norm,      // 3: airTemp / 50
      humidity_norm,      // 4: humidity / 100
      light_norm,         // 5: light / 100
      tank_norm,          // 6: tankLevel / 100
      health_score,       // 7: 1.0 - stress
      moisture_avg,       // 8: moisture average
      ec_avg,             // 9: EC average
      temp_avg,           // 10: temp average
      moisture_trend,     // 11: moisture trend
      ec_trend,           // 12: EC trend
      drought_stress,     // 13: drought stress indicator
      waterlogging_stress,// 14: waterlogging stress
      nutrient_stress,    // 15: nutrient stress
      temp_stress,        // 16: temperature stress
      light_stress        // 17: light stress
    ];
    
    // Ensure exactly 18 features
    if (features.length !== 18) {
      console.error(`Feature vector has ${features.length} features, expected 18`);
      // Pad or truncate to 18
      while (features.length < 18) features.push(0.0);
      features.splice(18);
    }
    
    // Try ML backend first (preferred - uses real .tflite model)
    if (window.modelLoaded) {
      try {
        const response = await fetch('http://localhost:5000/infer', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          mode: 'cors',
          body: JSON.stringify({
            project: 'smart_irrigation_system',
            features: features
          })
        });
        
        if (response.ok) {
          const data = await response.json();
          const probabilities = data.probabilities;
          const maxIdx = data.winning_index;
          
          return {
            class: maxIdx,
            className: ["Optimal", "Good", "Needs Water", "Critical"][maxIdx],
            confidence: probabilities[maxIdx],
            reasons: ["ML backend model prediction"],
            scores: probabilities,
          };
        }
      } catch (error) {
        // Backend unavailable, try TensorFlow.js
      }
    }
    
    // Fallback to TensorFlow.js model
    if (window.mlModel && window.modelLoaded) {
      try {
        const input = tf.tensor2d([features], [1, 18]);
        const prediction = window.mlModel.predict(input);
        const probs = await prediction.data();
        input.dispose();
        prediction.dispose();
        
        const probabilities = Array.from(probs);
        const maxIdx = probabilities.indexOf(Math.max(...probabilities));
        
        return {
          class: maxIdx,
          className: ["Optimal", "Good", "Needs Water", "Critical"][maxIdx],
          confidence: probabilities[maxIdx],
          reasons: ["TensorFlow.js model prediction"],
          scores: probabilities,
        };
      } catch (error) {
        console.error("ML inference error:", error);
        // Fall through to heuristic
      }
    }
    
    // Heuristic fallback
    let score = 0;
    let reasons = [];
    if (this.moisture < 45) { score += 3; reasons.push("Moisture too low"); }
    else if (this.moisture < 60) { score += 2; reasons.push("Moisture slightly low"); }
    else if (this.moisture > 85) { score += 1; reasons.push("Moisture high"); }
    if (this.ec < 0.3 || this.ec > 2.5) { score += 2; reasons.push("EC out of range"); }
    else if (this.ec < 0.8 || this.ec > 2.0) { score += 1; reasons.push("EC suboptimal"); }
    if (this.soilTemp < 10 || this.soilTemp > 35) { score += 2; reasons.push("Temperature stress"); }
    else if (this.soilTemp < 15 || this.soilTemp > 30) { score += 1; reasons.push("Temperature off"); }
    if (this.light < 20) { score += 1; reasons.push("Low light"); }
    if (this.tankLevel < 10) { score += 1; reasons.push("Water tank low"); }
    
    let classification = Math.min(3, Math.floor(score / 2));
    let confidence = 0.85 + Math.random() * 0.15;
    
    return {
      class: classification,
      className: ["Optimal", "Good", "Needs Water", "Critical"][classification],
      confidence: confidence,
      reasons: reasons,
      scores: this.getClassScores(score),
    };
  }

  getClassScores(baseScore) {
    // Softmax-like distribution
    const scores = [];
    for (let i = 0; i < 4; i++) {
      scores.push(Math.exp(-Math.pow(baseScore - i * 2, 2) / 2) / 2); // Gaussian distribution
    }
    const sum = scores.reduce((a, b) => a + b, 0);
    return scores.map((s) => s / sum);
  }

  addEvent(message) {
    const time = new Date().toLocaleTimeString();
    this.eventLog.unshift(`[${time}] ${message}`);
    if (this.eventLog.length > 50) {
      this.eventLog.pop();
    }
  }

  async getState() {
    const health = await this.classifyHealth();
    return {
      moisture: this.moisture.toFixed(1),
      ec: this.ec.toFixed(2),
      soilTemp: this.soilTemp.toFixed(1),
      airTemp: this.airTemp.toFixed(1),
      humidity: this.humidity.toFixed(1),
      light: this.light.toFixed(0),
      tankLevel: this.tankLevel.toFixed(1),
      pumpActive: this.pumpActive,
      totalIrrigation: Math.round(this.totalIrrigationMs / 60000), // minutes
      cycleTime: this.pumpActive
        ? Math.round((new Date() - this.cycleStartTime) / 1000)
        : 0,
      health: health,
      eventLog: this.eventLog,
    };
  }
}

// TensorFlow.js model
let mlModel = null;
let modelLoaded = false;

// Load ML model - try backend first, then TensorFlow.js, then heuristic
async function loadMLModel() {
  if (modelLoaded) return;
  
  // First, check if ML backend is available (preferred - uses real .tflite model)
  try {
    const response = await fetch('http://localhost:5000/health', { method: 'GET', mode: 'cors' });
    if (response.ok) {
      const healthData = await response.json();
      if (healthData.models_loaded.includes('smart_irrigation_system')) {
        modelLoaded = true;
        window.modelLoaded = true;
        console.log("✓ ML Backend server available - using real TinyML models");
        return true;
      }
    }
  } catch (error) {
    // Backend not available, continue to TensorFlow.js
  }
  
  // Fallback to TensorFlow.js (only if backend is not available)
  // Note: TensorFlow.js models may not exist - this is expected if using backend
  try {
    const modelPath = '../ml/training/artifacts/tfjs_model/model.json';
    mlModel = await tf.loadLayersModel(modelPath);
    window.mlModel = mlModel;
    window.modelLoaded = true;
    modelLoaded = true;
    console.log("✓ TensorFlow.js model loaded successfully - using real ML inference");
    return true;
  } catch (error) {
    // TensorFlow.js model not available - this is OK if using backend
    // Only log as warning if backend was also unavailable
    if (error.message && error.message.includes('404')) {
      // Suppress 404 errors - TensorFlow.js models are optional when using backend
      console.log("TensorFlow.js model not found (this is OK if ML backend is running)");
    } else {
      console.warn("Could not load TensorFlow.js model, using heuristic fallback:", error);
    }
    return false;
  }
}

// Global simulator instance
let simulator = new IrrigationSimulator();

// Chart instances
let charts = {
  moisture: null,
  ec: null,
  soilTemp: null,
  healthState: null,
  pump: null,
  tank: null,
  humidity: null,
  light: null
};

// Chart initialization flag
let chartsInitialized = false;

// Chart data storage
const MAX_CHART_DATA_POINTS = 50;
let chartData = {
  moisture: { labels: [], values: [] },
  ec: { labels: [], values: [] },
  soilTemp: { labels: [], values: [] },
  healthState: { labels: [], values: [] },
  pump: { labels: [], values: [] },
  tank: { labels: [], values: [] },
  humidity: { labels: [], values: [] },
  light: { labels: [], values: [] }
};

// Initialize charts
function initializeCharts() {
  // Prevent multiple initializations
  if (chartsInitialized) {
    return;
  }

  // Destroy existing charts if they exist
  Object.keys(charts).forEach(key => {
    if (charts[key]) {
      try {
        charts[key].destroy();
      } catch (e) {
        // Chart might already be destroyed
      }
      charts[key] = null;
    }
  });
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: true,
    aspectRatio: 2,
    plugins: {
      legend: { display: false },
      tooltip: { mode: 'index', intersect: false }
    },
    scales: {
      x: {
        grid: { color: 'rgba(0, 0, 0, 0.1)' },
        ticks: { color: '#2c3e50', maxTicksLimit: 10, font: { size: 11 } }
      },
      y: {
        grid: { color: 'rgba(0, 0, 0, 0.1)' },
        ticks: { color: '#2c3e50', font: { size: 11 } }
      }
    },
    elements: {
      point: { radius: 2, hoverRadius: 4 },
      line: { tension: 0.4, borderWidth: 2 }
    }
  };

  try {
    charts.moisture = new Chart(document.getElementById('chart-moisture'), {
      type: 'line',
      data: { labels: [], datasets: [{ data: [], borderColor: '#667eea', backgroundColor: 'rgba(102, 126, 234, 0.1)', fill: true }] },
      options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 100 } } }
    });
  } catch (e) { console.error("Failed to create chart-moisture:", e); }

  try {
    charts.ec = new Chart(document.getElementById('chart-ec'), {
      type: 'line',
      data: { labels: [], datasets: [{ data: [], borderColor: '#764ba2', backgroundColor: 'rgba(118, 75, 162, 0.1)', fill: true }] },
      options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 3 } } }
    });
  } catch (e) { console.error("Failed to create chart-ec:", e); }

  try {
    charts.soilTemp = new Chart(document.getElementById('chart-soil-temp'), {
      type: 'line',
      data: { labels: [], datasets: [{ data: [], borderColor: '#ff6b6b', backgroundColor: 'rgba(255, 107, 107, 0.1)', fill: true }] },
      options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 10, max: 40 } } }
    });
  } catch (e) { console.error("Failed to create chart-soil-temp:", e); }

  try {
    charts.healthState = new Chart(document.getElementById('chart-health-state'), {
      type: 'line',
      data: { labels: [], datasets: [{ data: [], borderColor: '#9c27b0', backgroundColor: 'rgba(156, 39, 176, 0.1)', fill: true, stepped: 'after' }] },
      options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: -0.5, max: 3.5, ticks: { stepSize: 1, callback: v => ['Optimal', 'Good', 'Needs Water', 'Critical'][v] || '' } } } }
    });
  } catch (e) { console.error("Failed to create chart-health-state:", e); }

  try {
    charts.pump = new Chart(document.getElementById('chart-pump'), {
      type: 'line',
      data: { labels: [], datasets: [{ data: [], borderColor: '#2196f3', backgroundColor: 'rgba(33, 150, 243, 0.1)', fill: true, stepped: 'after' }] },
      options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: -0.2, max: 1.2, ticks: { stepSize: 1, callback: v => v === 0 ? 'OFF' : v === 1 ? 'ON' : '' } } } }
    });
  } catch (e) { console.error("Failed to create chart-pump:", e); }

  try {
    charts.tank = new Chart(document.getElementById('chart-tank'), {
      type: 'line',
      data: { labels: [], datasets: [{ data: [], borderColor: '#4caf50', backgroundColor: 'rgba(76, 175, 80, 0.1)', fill: true }] },
      options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 100 } } }
    });
  } catch (e) { console.error("Failed to create chart-tank:", e); }

  try {
    charts.humidity = new Chart(document.getElementById('chart-humidity'), {
      type: 'line',
      data: { labels: [], datasets: [{ data: [], borderColor: '#00bcd4', backgroundColor: 'rgba(0, 188, 212, 0.1)', fill: true }] },
      options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 100 } } }
    });
  } catch (e) { console.error("Failed to create chart-humidity:", e); }

  try {
    charts.light = new Chart(document.getElementById('chart-light'), {
      type: 'line',
      data: { labels: [], datasets: [{ data: [], borderColor: '#ffd54f', backgroundColor: 'rgba(255, 213, 79, 0.1)', fill: true }] },
      options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 100 } } }
    });
  } catch (e) { console.error("Failed to create chart-light:", e); }

  // Mark charts as initialized
  chartsInitialized = true;
}

// Update charts with new data
function updateCharts(state) {
  const now = new Date().toLocaleTimeString();

  function addData(chartName, value) {
    const data = chartData[chartName];
    data.labels.push(now);
    data.values.push(value);
    if (data.labels.length > MAX_CHART_DATA_POINTS) {
      data.labels.shift();
      data.values.shift();
    }
  }

  addData('moisture', parseFloat(state.moisture));
  addData('ec', parseFloat(state.ec));
  addData('soilTemp', parseFloat(state.soilTemp));
  addData('healthState', state.health.class);
  addData('pump', state.pumpActive ? 1 : 0);
  addData('tank', parseFloat(state.tankLevel));
  addData('humidity', parseFloat(state.humidity));
  addData('light', parseFloat(state.light));

  // Update each chart
  Object.keys(charts).forEach(key => {
    if (charts[key] && chartData[key]) {
      charts[key].data.labels = chartData[key].labels;
      charts[key].data.datasets[0].data = chartData[key].values;
      charts[key].update('none');
    }
  });
}

// Update UI with sensor data and AI results
async function updateUI() {
  const state = await simulator.getState();

  // Update sensor values
  const moistureEl = document.getElementById("moisture-value");
  if (moistureEl) moistureEl.textContent = `${state.moisture}%`;
  
  const ecEl = document.getElementById("ec-value");
  if (ecEl) ecEl.textContent = `${state.ec} mS/cm`;
  
  const soilTempEl = document.getElementById("soil-temp-value");
  if (soilTempEl) soilTempEl.textContent = `${state.soilTemp}°C`;
  
  const airTempEl = document.getElementById("air-temp-value");
  if (airTempEl) airTempEl.textContent = `${state.airTemp}°C`;
  
  const humidityEl = document.getElementById("humidity-value");
  if (humidityEl) humidityEl.textContent = state.humidity;
  
  const lightEl = document.getElementById("light-value");
  if (lightEl) lightEl.textContent = state.light;
  
  const tankEl = document.getElementById("tank-value");
  if (tankEl) tankEl.textContent = `${state.tankLevel}%`;

  // Update irrigation control
  const pumpEl = document.getElementById("pump-value");
  if (pumpEl) {
    pumpEl.textContent = state.pumpActive
      ? `ON (${state.cycleTime}s)`
      : "OFF";
  }
  
  const totalTimeEl = document.getElementById("total-time");
  if (totalTimeEl) totalTimeEl.textContent = state.totalIrrigation;

  // Update AI classification bars
  const health = state.health;
  if (!health || !health.scores || !Array.isArray(health.scores)) {
    console.error("Health object is invalid:", health);
    return;
  }
  
  const colors = ["#4CAF50", "#8BC34A", "#FFC107", "#F44336"]; // Green to Red
  const classNames = ["optimal", "good", "needs", "critical"];

  classNames.forEach((name, i) => {
    const bar = document.getElementById(`bar-${name}`);
    if (bar) {
      const fill = bar.querySelector(".bar-fill");
      if (fill && health.scores[i] !== undefined) {
        fill.style.width = (health.scores[i] * 100).toFixed(1) + "%";
        fill.style.backgroundColor = colors[i];
      }
    }
  });

  // Update AI result
  const stateBadge = document.getElementById("state-badge");
  if (stateBadge && health.className) {
    stateBadge.textContent = health.className.toUpperCase();
    stateBadge.className = `state-badge state-${classNames[health.class] || "optimal"}`;
  }
  
  const stateDetails = document.getElementById("state-details");
  if (stateDetails && health.reasons) {
    stateDetails.textContent = health.reasons.join(" | ");
  }
  
  const confidence = document.getElementById("confidence");
  if (confidence && health.confidence !== undefined) {
    confidence.textContent = `Confidence: ${(health.confidence * 100).toFixed(1)}%`;
  }

  // Update irrigation stats
  const cycleStatus = state.pumpActive ? `Running (${state.cycleTime}s)` : "Idle";
  const cycleStatusEl = document.getElementById("cycle-status");
  if (cycleStatusEl) cycleStatusEl.textContent = cycleStatus;
  
  const cycleTimeEl = document.getElementById("cycle-time");
  if (cycleTimeEl) cycleTimeEl.textContent = `Duration: ${state.cycleTime}s`;
  
  const dailyTotalEl = document.getElementById("daily-total");
  if (dailyTotalEl) dailyTotalEl.textContent = `${state.totalIrrigation} min`;

  // Calculate efficiency score (lower moisture variance = better)
  let efficiency = 100;
  if (simulator.moistureHistory.length > 10) {
    const mean =
      simulator.moistureHistory.reduce((a, b) => a + b, 0) /
      simulator.moistureHistory.length;
    const variance =
      simulator.moistureHistory.reduce((sq, n) => sq + (n - mean) ** 2, 0) /
      simulator.moistureHistory.length;
    efficiency = Math.max(0, 100 - Math.sqrt(variance));
  }
  const efficiencyEl = document.getElementById("efficiency-score");
  if (efficiencyEl) efficiencyEl.textContent = efficiency.toFixed(0) + "%";

  // Health trend (comparing recent vs older history)
  let trend = "Stable";
  if (simulator.moistureHistory.length > 20) {
    const recent =
      simulator.moistureHistory.slice(-10).reduce((a, b) => a + b, 0) / 10;
    const older = simulator.moistureHistory
      .slice(-20, -10)
      .reduce((a, b) => a + b, 0) / 10;
    if (recent > older + 5) trend = "Increasing ↑";
    else if (recent < older - 5) trend = "Decreasing ↓";
  }
  const trendEl = document.getElementById("health-trend");
  if (trendEl) trendEl.textContent = trend;

  // Update event log
  const eventLogEl = document.getElementById("event-log");
  if (eventLogEl) {
    eventLogEl.innerHTML = "";
    if (state.eventLog && Array.isArray(state.eventLog)) {
      state.eventLog.slice(0, 15).forEach((event) => {
        const li = document.createElement("li");
        li.textContent = event;
        eventLogEl.appendChild(li);
      });
    }
  }

  // Update timestamp
  const lastUpdateEl = document.getElementById("last-update");
  if (lastUpdateEl) lastUpdateEl.textContent = new Date().toLocaleTimeString();

  // Update charts
  updateCharts(state);
}

// Main animation loop
async function animate() {
  simulator.update();
  await updateUI();
  requestAnimationFrame(animate);
}

// Initialize ML model and start
(async () => {
  await loadMLModel();
  
  // Initialize charts when DOM is ready (only once)
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      if (!chartsInitialized) {
        initializeCharts();
      }
    });
  } else {
    if (!chartsInitialized) {
      initializeCharts();
    }
  }
  
  animate();
})();

// Start simulation when page loads
window.addEventListener("load", () => {
  // Charts should already be initialized, but ensure they are
  if (!chartsInitialized) {
    initializeCharts();
  }
  // Manually trigger pump test after 5 seconds
  setTimeout(() => {
    simulator.addEvent("Demo mode: Simulating soil drying cycle");
  }, 5000);
});
