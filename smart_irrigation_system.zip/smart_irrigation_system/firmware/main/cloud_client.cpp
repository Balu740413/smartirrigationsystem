#include "cloud_client.hpp"
#include "esp_log.h"
#include "esp_http_client.h"
#include "mqtt_client.h"
#include <cstring>
#include <cstdio>

static const char *TAG = "CLOUD_CLIENT";

esp_err_t CloudClient::init() {
    ESP_LOGI(TAG, "Initializing cloud client...");
    
    #ifdef CONFIG_IRRIGATION_USE_THINGSPEAK
    mode = THINGSPEAK;
    ESP_LOGI(TAG, "Using ThingSpeak mode");
    #else
    mode = MQTT;
    ESP_LOGI(TAG, "Using MQTT mode");
    #endif
    
    publish_interval_ms = 5000;  // Publish every 5 seconds
    last_publish_time_ms = 0;
    
    return ESP_OK;
}

esp_err_t CloudClient::publish(const SensorReadings &readings, const InferenceResult &result) {
    uint32_t current_time = esp_timer_get_time() / 1000;
    
    if (current_time - last_publish_time_ms < publish_interval_ms) {
        return ESP_OK;  // Not time to publish yet
    }
    
    last_publish_time_ms = current_time;
    
    if (mode == THINGSPEAK) {
        return publish_to_thingspeak(readings, result);
    } else if (mode == MQTT) {
        return publish_to_mqtt(readings, result);
    }
    
    return ESP_OK;
}

esp_err_t CloudClient::publish_to_thingspeak(const SensorReadings &readings, const InferenceResult &result) {
    #ifdef CONFIG_IRRIGATION_THINGSPEAK_API_KEY
    const char *api_key = CONFIG_IRRIGATION_THINGSPEAK_API_KEY;
    int channel_id = CONFIG_IRRIGATION_THINGSPEAK_CHANNEL_ID;
    
    // Build URL with all 8 fields
    char url[512];
    snprintf(url, sizeof(url),
        "http://api.thingspeak.com/update?api_key=%s"
        "&field1=%.1f&field2=%.2f&field3=%.1f&field4=%d"
        "&field5=%d&field6=%.1f&field7=%.1f&field8=%.1f",
        api_key,
        readings.soil_moisture * 100,        // field1: Moisture %
        readings.soil_conductivity,          // field2: EC mS/cm
        readings.soil_temperature,           // field3: Soil Temp °C
        result.predicted_class,              // field4: Health state
        0,                                   // field5: Pump status (placeholder)
        readings.water_tank_level * 100,     // field6: Tank level %
        readings.ambient_humidity,           // field7: Humidity %
        readings.light_level * 100           // field8: Light level %
    );
    
    esp_http_client_config_t config{};
    config.url = url;
    config.method = HTTP_METHOD_GET;
    config.timeout_ms = 5000;
    
    esp_http_client_handle_t client = esp_http_client_init(&config);
    esp_err_t err = esp_http_client_perform(client);
    
    if (err == ESP_OK) {
        int status_code = esp_http_client_get_status_code(client);
        ESP_LOGI(TAG, "ThingSpeak: HTTP %d", status_code);
    } else {
        ESP_LOGE(TAG, "ThingSpeak publish failed: %s", esp_err_to_name(err));
    }
    
    esp_http_client_cleanup(client);
    return err;
    #endif
    
    return ESP_OK;
}

esp_err_t CloudClient::publish_to_mqtt(const SensorReadings &readings, const InferenceResult &result) {
    // MQTT publishing would be implemented here
    // Placeholder for MQTT integration
    
    char state_name[32];
    const char *states[] = {"Optimal", "Good", "Needs Water", "Critical"};
    snprintf(state_name, sizeof(state_name), "%s", states[result.predicted_class]);
    
    ESP_LOGI(TAG, "MQTT: Moisture=%.1f%%, EC=%.2f, State=%s",
             readings.soil_moisture * 100,
             readings.soil_conductivity,
             state_name);
    
    return ESP_OK;
}
