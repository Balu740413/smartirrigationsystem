#pragma once

#include <cstdint>
#include "esp_err.h"
#include "feature_pipeline.hpp"

struct InferenceResult {
    uint32_t predicted_class;  // 0=Optimal, 1=Good, 2=Needs Water, 3=Critical
    float confidence;          // 0-1 confidence score
    float class_scores[4];     // Score for each class
    uint32_t inference_time_ms;
};

class AiProcessor {
public:
    esp_err_t init();
    esp_err_t infer(const FeatureVector &features, InferenceResult &out_result);
    void log_inference_result(const InferenceResult &result);

private:
    void softmax(float *logits, float *output, size_t size);
};
