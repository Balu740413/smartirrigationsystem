#pragma once

extern const unsigned char ai_model_data[];
extern const unsigned int ai_model_data_len;
