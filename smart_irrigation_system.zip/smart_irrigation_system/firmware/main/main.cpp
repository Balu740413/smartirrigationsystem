#include <cstring>

#include "ai_processor.hpp"
#include "alerts.hpp"
#include "cloud_client.hpp"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "feature_pipeline.hpp"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "irrigation_controller.hpp"
#include "nvs_flash.h"
#include "sensors.hpp"
#include "simulation.hpp"

#ifndef CONFIG_IRRIGATION_WIFI_SSID
#define CONFIG_IRRIGATION_WIFI_SSID "ssid"
#endif

#ifndef CONFIG_IRRIGATION_WIFI_PASSWORD
#define CONFIG_IRRIGATION_WIFI_PASSWORD "password"
#endif

namespace {
constexpr char kTag[] = "SmartIrrigationSystem";
constexpr gpio_num_t kConsentButton = GPIO_NUM_1;

SensorHub sensor_hub;
FeaturePipeline feature_pipeline;
AiProcessor ai_processor;
AlertManager alert_manager;
IrrigationController irrigation_controller;
CloudClient cloud_client;
SimulationEngine simulation_engine;

QueueHandle_t sensor_queue;

bool user_consent_granted() {
    return gpio_get_level(kConsentButton) == 1;
}

void init_consent_button() {
    gpio_config_t cfg{};
    cfg.mode = GPIO_MODE_INPUT;
    cfg.pull_up_en = GPIO_PULLUP_ENABLE;
    cfg.pin_bit_mask = (1ULL << kConsentButton);
    gpio_config(&cfg);
}

void wifi_init_sta() {
    ESP_LOGI(kTag, "Initializing WiFi...");
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    wifi_config_t wifi_config{};
    strcpy(reinterpret_cast<char *>(wifi_config.sta.ssid),
           CONFIG_IRRIGATION_WIFI_SSID);
    strcpy(reinterpret_cast<char *>(wifi_config.sta.password),
           CONFIG_IRRIGATION_WIFI_PASSWORD);
    wifi_config.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_LOGI(kTag, "WiFi initialization finished");
}

void sensor_task(void *) {
    SensorReadings readings;
    while (true) {
        if (simulation_engine.is_simulation_enabled()) {
            simulation_engine.update_simulated_data(readings);
        } else {
            if (sensor_hub.sample(readings) != ESP_OK) {
                vTaskDelay(pdMS_TO_TICKS(200));
                continue;
            }
        }
        xQueueOverwrite(sensor_queue, &readings);
        vTaskDelay(pdMS_TO_TICKS(200));
    }
}

void inference_task(void *) {
    FeatureVector features;
    SensorReadings readings;
    InferenceResult result{};
    
    while (true) {
        if (xQueueReceive(sensor_queue, &readings, portMAX_DELAY) == pdTRUE) {
            feature_pipeline.build(readings, features);
            if (ai_processor.infer(features, result) == ESP_OK) {
                // Update alerts based on inference
                alert_manager.update(readings, result);
                
                // Update irrigation control
                irrigation_controller.update(readings, result.predicted_class);
                
                // Publish to cloud if user consented
                if (user_consent_granted()) {
                    cloud_client.publish(readings, result);
                }
                
                // Log statistics periodically
                static uint32_t log_count = 0;
                if (++log_count % 10 == 0) {
                    const char *state_names[] = {"OPTIMAL", "GOOD", "NEEDS_WATER", "CRITICAL"};
                    ESP_LOGI(kTag, 
                        "Soil: %.1f%% | EC: %.2f | Temp: %.1f°C | Light: %.0f%% | State: %s",
                        readings.soil_moisture * 100,
                        readings.soil_conductivity,
                        readings.soil_temperature,
                        readings.light_level * 100,
                        state_names[result.predicted_class]);
                    
                    if (irrigation_controller.is_pump_active()) {
                        ESP_LOGI(kTag, "Pump: ACTIVE | Total irrigation: %lu ms",
                                 irrigation_controller.get_total_irrigation_time());
                    }
                }
            }
        }
    }
}
}  // namespace

extern "C" void app_main(void) {
    ESP_LOGI(kTag, "=================================");
    ESP_LOGI(kTag, "Smart Irrigation System Starting");
    ESP_LOGI(kTag, "=================================");
    
    // Initialize NVS
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);
    
    // Initialize WiFi
    wifi_init_sta();
    
    // Initialize consent button
    init_consent_button();
    
    // Initialize components
    ESP_ERROR_CHECK(sensor_hub.init());
    ESP_ERROR_CHECK(feature_pipeline.init());
    ESP_ERROR_CHECK(ai_processor.init());
    ESP_ERROR_CHECK(alert_manager.init());
    ESP_ERROR_CHECK(irrigation_controller.init());
    ESP_ERROR_CHECK(cloud_client.init());
    ESP_ERROR_CHECK(simulation_engine.init());
    
    // Create queue for sensor data
    sensor_queue = xQueueCreate(1, sizeof(SensorReadings));
    if (sensor_queue == NULL) {
        ESP_LOGE(kTag, "Failed to create sensor queue");
        return;
    }
    
    // Create tasks
    xTaskCreate(sensor_task, "sensor_task", 4096, nullptr, 5, nullptr);
    xTaskCreate(inference_task, "inference_task", 8192, nullptr, 5, nullptr);
    
    ESP_LOGI(kTag, "All systems initialized");
    ESP_LOGI(kTag, "Console: Monitor/Feedback enabled");
    ESP_LOGI(kTag, "Cloud Publishing: %s", user_consent_granted() ? "ENABLED" : "DISABLED");
}
