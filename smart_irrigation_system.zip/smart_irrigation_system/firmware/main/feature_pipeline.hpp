#pragma once

#include <cstdint>
#include "esp_err.h"
#include "sensors.hpp"

struct FeatureVector {
    std::array<float, 18> data;
    uint32_t timestamp;
};

class FeaturePipeline {
public:
    esp_err_t init();
    void build(const SensorReadings &readings, FeatureVector &out_features);

private:
    // Feature engineering functions
    void extract_raw_features(const SensorReadings &readings, std::array<float, 8> &raw);
    void compute_rolling_averages(std::array<float, 5> &rolling_avg);
    void compute_stress_indicators(const SensorReadings &readings, std::array<float, 5> &stress);
    void normalize_features(FeatureVector &features);
    
    // State tracking
    std::array<float, 5> moisture_history;  // Rolling window of moisture readings
    std::array<float, 5> ec_history;         // Rolling window of EC readings
    std::array<float, 5> temp_history;       // Rolling window of temperature readings
    uint32_t last_update_ms;
    uint32_t sample_count;
};
