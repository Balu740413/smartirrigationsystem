#include "feature_pipeline.hpp"
#include "esp_log.h"
#include "esp_timer.h"

static const char *TAG = "FEATURE_PIPELINE";

esp_err_t FeaturePipeline::init() {
    ESP_LOGI(TAG, "Initializing feature pipeline...");
    last_update_ms = 0;
    sample_count = 0;
    
    // Initialize rolling averages
    for (auto &val : moisture_history) val = 0.65f;
    for (auto &val : ec_history) val = 1.2f;
    for (auto &val : temp_history) val = 24.0f;
    
    return ESP_OK;
}

void FeaturePipeline::build(const SensorReadings &readings, FeatureVector &out_features) {
    // Update rolling histories
    moisture_history[sample_count % 5] = readings.soil_moisture;
    ec_history[sample_count % 5] = readings.soil_conductivity;
    temp_history[sample_count % 5] = readings.soil_temperature;
    sample_count++;
    
    // Extract raw features
    std::array<float, 8> raw_features;
    extract_raw_features(readings, raw_features);
    
    // Compute rolling averages
    std::array<float, 5> rolling_avg;
    compute_rolling_averages(rolling_avg);
    
    // Compute stress indicators
    std::array<float, 5> stress_indicators;
    compute_stress_indicators(readings, stress_indicators);
    
    // Combine all features (8 raw + 5 rolling + 5 stress = 18 features)
    for (size_t i = 0; i < 8; i++) out_features.data[i] = raw_features[i];
    for (size_t i = 0; i < 5; i++) out_features.data[8 + i] = rolling_avg[i];
    for (size_t i = 0; i < 5; i++) out_features.data[13 + i] = stress_indicators[i];
    
    out_features.timestamp = esp_timer_get_time() / 1000;
    normalize_features(out_features);
}

void FeaturePipeline::extract_raw_features(const SensorReadings &readings, std::array<float, 8> &raw) {
    raw[0] = readings.soil_moisture;
    raw[1] = readings.soil_conductivity / 3.0f;  // Normalize to 0-1
    raw[2] = readings.soil_temperature / 50.0f;  // Normalize
    raw[3] = readings.ambient_temperature / 50.0f;  // Normalize
    raw[4] = readings.ambient_humidity / 100.0f;  // Already 0-100
    raw[5] = readings.light_level;  // Already 0-1
    raw[6] = readings.water_tank_level;  // Already 0-1
    raw[7] = readings.soil_health_score;  // Already 0-1
}

void FeaturePipeline::compute_rolling_averages(std::array<float, 5> &rolling_avg) {
    float moisture_avg = 0.0f, ec_avg = 0.0f, temp_avg = 0.0f;
    for (size_t i = 0; i < 5; i++) {
        moisture_avg += moisture_history[i];
        ec_avg += ec_history[i];
        temp_avg += temp_history[i];
    }
    rolling_avg[0] = moisture_avg / 5.0f;
    rolling_avg[1] = ec_avg / 15.0f;  // Normalize
    rolling_avg[2] = temp_avg / 250.0f;  // Normalize
    rolling_avg[3] = (moisture_history[0] - moisture_history[4]) / 5.0f;  // Moisture trend
    rolling_avg[4] = (ec_history[0] - ec_history[4]) / 15.0f;  // EC trend
}

void FeaturePipeline::compute_stress_indicators(const SensorReadings &readings, std::array<float, 5> &stress) {
    // Drought stress indicator
    stress[0] = readings.soil_moisture < 0.40f ? 1.0f : (1.0f - readings.soil_moisture);
    
    // Waterlogging indicator
    stress[1] = readings.soil_moisture > 0.85f ? 1.0f : 0.0f;
    
    // Nutrient imbalance (EC too high or too low)
    stress[2] = readings.soil_conductivity < 0.3f || readings.soil_conductivity > 2.5f ? 1.0f : 0.0f;
    
    // Temperature stress (too cold or too hot)
    stress[3] = (readings.soil_temperature < 10.0f || readings.soil_temperature > 35.0f) ? 1.0f : 0.0f;
    
    // Light stress
    stress[4] = readings.light_level < 0.2f ? 0.8f : 0.0f;
}

void FeaturePipeline::normalize_features(FeatureVector &features) {
    // Ensure all features are in 0-1 range
    for (auto &val : features.data) {
        if (val < 0.0f) val = 0.0f;
        else if (val > 1.0f) val = 1.0f;
    }
}
