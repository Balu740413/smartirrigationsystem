#include "alerts.hpp"
#include "esp_log.h"
#include "driver/gpio.h"
#include "driver/ledc.h"

static const char *TAG = "ALERTS";

esp_err_t AlertManager::init() {
    ESP_LOGI(TAG, "Initializing alert manager...");
    ESP_ERROR_CHECK(init_leds());
    ESP_ERROR_CHECK(init_buzzer());
    last_state = OPTIMAL;
    last_alert_time_ms = 0;
    return ESP_OK;
}

esp_err_t AlertManager::init_leds() {
    gpio_config_t cfg{};
    cfg.mode = GPIO_MODE_OUTPUT;
    cfg.pin_bit_mask = (1ULL << 2) | (1ULL << 4);  // GPIO 2 (green), GPIO 4 (red)
    gpio_config(&cfg);
    
    // Initialize LEDs off
    gpio_set_level(GPIO_NUM_2, 0);
    gpio_set_level(GPIO_NUM_4, 0);
    return ESP_OK;
}

esp_err_t AlertManager::init_buzzer() {
    // Setup PWM for buzzer on GPIO 5
    ledc_timer_config_t timer_cfg{};
    timer_cfg.duty_resolution = LEDC_TIMER_8_BIT;
    timer_cfg.freq_hz = 1000;
    timer_cfg.speed_mode = LEDC_LOW_SPEED_MODE;
    timer_cfg.timer_num = LEDC_TIMER_0;
    ledc_timer_config(&timer_cfg);
    
    ledc_channel_config_t channel_cfg{};
    channel_cfg.channel = LEDC_CHANNEL_0;
    channel_cfg.duty = 0;
    channel_cfg.gpio_num = 5;
    channel_cfg.intr_type = LEDC_INTR_DISABLE;
    channel_cfg.speed_mode = LEDC_LOW_SPEED_MODE;
    channel_cfg.timer_sel = LEDC_TIMER_0;
    ledc_channel_config(&channel_cfg);
    
    return ESP_OK;
}

void AlertManager::update(const SensorReadings &readings, const InferenceResult &result) {
    AlertState current_state = static_cast<AlertState>(result.predicted_class);
    
    if (current_state != last_state) {
        update_alert_pattern(current_state);
        last_state = current_state;
    }
    
    // Periodic visual/audio feedback for warnings and critical
    uint32_t current_time = esp_timer_get_time() / 1000;
    if (current_state >= NEEDS_WATER && (current_time - last_alert_time_ms > 3000)) {
        play_alert_tone(1000, 100, current_state == CRITICAL ? 3 : 1);
        last_alert_time_ms = current_time;
    }
}

void AlertManager::set_led_state(bool green_on, bool red_on) {
    gpio_set_level(GPIO_NUM_2, green_on ? 1 : 0);
    gpio_set_level(GPIO_NUM_4, red_on ? 1 : 0);
    ESP_LOGI(TAG, "LEDs: Green=%d, Red=%d", green_on, red_on);
}

void AlertManager::play_alert_tone(uint32_t frequency, uint32_t duration_ms, uint32_t beeps) {
    for (uint32_t i = 0; i < beeps; i++) {
        ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, 128);
        ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
        vTaskDelay(pdMS_TO_TICKS(duration_ms));
        
        ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, 0);
        ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

void AlertManager::update_alert_pattern(uint32_t soil_health_state) {
    switch (soil_health_state) {
        case OPTIMAL:
        case GOOD:
            set_led_state(true, false);  // Green on
            ESP_LOGI(TAG, "Soil health: OPTIMAL/GOOD");
            break;
        case NEEDS_WATER:
            set_led_state(false, false);  // Both off, will blink
            play_alert_tone(1000, 150, 1);
            ESP_LOGI(TAG, "Soil health: NEEDS_WATER");
            break;
        case CRITICAL:
            set_led_state(false, true);  // Red on
            play_alert_tone(2000, 200, 3);
            ESP_LOGI(TAG, "Soil health: CRITICAL");
            break;
        default:
            break;
    }
}
