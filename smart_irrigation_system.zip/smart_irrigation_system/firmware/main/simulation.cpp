#include "simulation.hpp"
#include "esp_log.h"
#include "esp_timer.h"
#include "math.h"

static const char *TAG = "SIMULATION_ENGINE";

esp_err_t SimulationEngine::init() {
    ESP_LOGI(TAG, "Initializing simulation engine...");
    
    update_count = 0;
    last_update_ms = 0;
    current_hour = 6.0f;  // Start at 6 AM
    moisture_level = 65.0f;
    ec_level = 1.2f;
    soil_temp = 24.0f;
    air_temp = 22.0f;
    humidity = 65.0f;
    tank_level = 1.0f;
    
    return ESP_OK;
}

void SimulationEngine::update_simulated_data(SensorReadings &out_readings) {
    uint32_t current_time_ms = esp_timer_get_time() / 1000;
    
    // Update simulation at 1Hz
    if (current_time_ms - last_update_ms < 1000) {
        return;
    }
    
    last_update_ms = current_time_ms;
    update_count++;
    
    // Simulate daily cycle (hour 0-23)
    current_hour = fmod(current_hour + 0.0167f, 24.0f);  // +1 minute per second
    
    // Update simulated sensor values
    simulate_moisture(moisture_level);
    simulate_conductivity(ec_level);
    simulate_temperatures(soil_temp, air_temp);
    simulate_humidity(humidity);
    simulate_light(out_readings.light_level);
    simulate_water_tank(tank_level);
    
    // Write to output
    out_readings.soil_moisture = moisture_level / 100.0f;
    out_readings.soil_conductivity = ec_level;
    out_readings.soil_temperature = soil_temp;
    out_readings.ambient_temperature = air_temp;
    out_readings.ambient_humidity = humidity;
    out_readings.water_tank_level = tank_level;
    
    // Mark all as valid
    out_readings.moisture_valid = true;
    out_readings.conductivity_valid = true;
    out_readings.temperature_valid = true;
    out_readings.humidity_valid = true;
    out_readings.light_valid = true;
    out_readings.tank_valid = true;
    
    if (update_count % 10 == 0) {
        ESP_LOGI(TAG, "Sim Hour: %.1f | Moisture: %.1f%% | EC: %.2f | Temp: %.1f°C",
                 current_hour, moisture_level, ec_level, soil_temp);
    }
}

void SimulationEngine::simulate_moisture(float &moisture) {
    // Gradually decrease due to evapotranspiration (0.5%/hour)
    moisture -= 0.5f / 60.0f;  // Per second
    
    // More evapotranspiration during day
    if (current_hour > 6.0f && current_hour < 18.0f) {
        moisture -= 0.3f / 60.0f;
    }
    
    // Clamp to reasonable range
    if (moisture < 20.0f) moisture = 20.0f;
    if (moisture > 95.0f) moisture = 95.0f;
}

void SimulationEngine::simulate_conductivity(float &ec) {
    // EC fluctuates slightly around 1.0-1.5
    static float ec_drift = 0.0f;
    ec_drift += (rand() % 100 - 50) * 0.0001f;  // Random drift
    
    if (ec_drift > 0.3f) ec_drift = 0.3f;
    if (ec_drift < -0.3f) ec_drift = -0.3f;
    
    ec = 1.2f + ec_drift;
}

void SimulationEngine::simulate_temperatures(float &soil_temp, float &air_temp) {
    // Daily temperature cycle
    float base_temp = 20.0f + 8.0f * sinf(M_PI * (current_hour - 6.0f) / 12.0f);
    soil_temp = base_temp + 2.0f;  // Soil warmer than air
    air_temp = base_temp;
    
    // Add small random variation
    soil_temp += (rand() % 100 - 50) * 0.01f;
    air_temp += (rand() % 100 - 50) * 0.01f;
}

void SimulationEngine::simulate_humidity(float &humidity) {
    // Inverse to temperature - higher humidity at night
    float base_humidity = 70.0f - 15.0f * sinf(M_PI * (current_hour - 6.0f) / 12.0f);
    humidity = base_humidity + (rand() % 100 - 50) * 0.1f;
    
    if (humidity < 30.0f) humidity = 30.0f;
    if (humidity > 95.0f) humidity = 95.0f;
}

void SimulationEngine::simulate_light(float &light) {
    // Simulate day/night cycle
    if (current_hour < 6.0f || current_hour > 18.0f) {
        light = 0.0f;  // Night
    } else {
        // Sunrise at 6, sunset at 18
        float midday = current_hour - 6.0f;  // 0 at 6AM, 12 at 6PM
        light = 0.95f * sinf(M_PI * midday / 12.0f);  // Peak at noon
        light += (rand() % 100 - 50) * 0.02f;  // Cloud variation
    }
    
    if (light < 0.0f) light = 0.0f;
    if (light > 1.0f) light = 1.0f;
}

void SimulationEngine::simulate_water_tank(float &level) {
    // Tank gradually depletes when pump is on
    // For simulation, assume pump cycles reduce tank by 5% per cycle
    // Tank refills slowly (simulating rain or manual refill)
    
    level -= 0.001f;  // Slow leak
    
    if (level < 0.1f) level = 0.1f;  // Don't go below 10%
    if (level > 1.0f) level = 1.0f;
}

bool SimulationEngine::is_simulation_enabled() const {
    return true;  // Always enabled for demo
}
