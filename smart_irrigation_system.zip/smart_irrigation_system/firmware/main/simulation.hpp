#pragma once

#include <cstdint>
#include "esp_err.h"
#include "sensors.hpp"

class SimulationEngine {
public:
    esp_err_t init();
    void update_simulated_data(SensorReadings &out_readings);
    bool is_simulation_enabled() const;

private:
    void simulate_moisture(float &moisture);
    void simulate_conductivity(float &ec);
    void simulate_temperatures(float &soil_temp, float &air_temp);
    void simulate_humidity(float &humidity);
    void simulate_light(float &light);
    void simulate_water_tank(float &level);
    
    uint32_t update_count;
    uint32_t last_update_ms;
    float current_hour;
    float moisture_level;
    float ec_level;
    float soil_temp;
    float air_temp;
    float humidity;
    float tank_level;
};
