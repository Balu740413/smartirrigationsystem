#pragma once

#include "esp_err.h"
#include "sensors.hpp"
#include "ai_processor.hpp"

class CloudClient {
public:
    esp_err_t init();
    esp_err_t publish(const SensorReadings &readings, const InferenceResult &result);

private:
    esp_err_t init_mqtt();
    esp_err_t init_http();
    
    esp_err_t publish_to_thingspeak(const SensorReadings &readings, const InferenceResult &result);
    esp_err_t publish_to_mqtt(const SensorReadings &readings, const InferenceResult &result);
    
    enum CloudMode {
        MQTT = 0,
        THINGSPEAK = 1,
        DISABLED = 2
    };
    
    CloudMode mode;
    uint32_t last_publish_time_ms;
    uint32_t publish_interval_ms;
};
