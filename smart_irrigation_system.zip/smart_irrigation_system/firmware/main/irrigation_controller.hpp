#pragma once

#include <cstdint>
#include "esp_err.h"
#include "sensors.hpp"

class IrrigationController {
public:
    esp_err_t init();
    void update(const SensorReadings &readings, uint32_t soil_health_state);
    bool is_pump_active() const;
    uint32_t get_total_irrigation_time() const;

private:
    esp_err_t init_pump_control();
    esp_err_t init_manual_button();
    
    void activate_pump();
    void deactivate_pump();
    bool check_manual_trigger();
    bool is_safe_to_water(const SensorReadings &readings) const;
    
    enum IrrigationState {
        IDLE = 0,
        WATERING = 1,
        WAITING = 2,
        BLOCKED = 3
    };
    
    IrrigationState pump_state;
    uint32_t pump_start_time_ms;
    uint32_t total_irrigation_ms;
    uint32_t last_watering_cycle_ms;
    float last_moisture_level;
    
    static constexpr uint32_t MOISTURE_THRESHOLD_LOW = 45;    // 45% - start watering
    static constexpr uint32_t MOISTURE_THRESHOLD_HIGH = 75;   // 75% - stop watering
    static constexpr uint32_t MAX_PUMP_DURATION = 30000;      // 30 seconds max
    static constexpr uint32_t PUMP_SAFETY_DELAY = 120000;     // 2 minute safety delay
};
