#pragma once

#include <cstdint>
#include "esp_err.h"
#include "sensors.hpp"
#include "ai_processor.hpp"

class AlertManager {
public:
    esp_err_t init();
    void update(const SensorReadings &readings, const InferenceResult &result);

private:
    esp_err_t init_leds();
    esp_err_t init_buzzer();
    
    void set_led_state(bool green_on, bool red_on);
    void play_alert_tone(uint32_t frequency, uint32_t duration_ms, uint32_t beeps);
    void update_alert_pattern(uint32_t soil_health_state);
    
    enum AlertState {
        OPTIMAL = 0,
        GOOD = 1,
        NEEDS_WATER = 2,
        CRITICAL = 3
    };
    
    AlertState last_state;
    uint32_t last_alert_time_ms;
};
