#include "irrigation_controller.hpp"
#include "esp_log.h"
#include "driver/gpio.h"
#include "esp_timer.h"

static const char *TAG = "IRRIGATION_CONTROLLER";

esp_err_t IrrigationController::init() {
    ESP_LOGI(TAG, "Initializing irrigation controller...");
    ESP_ERROR_CHECK(init_pump_control());
    ESP_ERROR_CHECK(init_manual_button());
    
    pump_state = IDLE;
    pump_start_time_ms = 0;
    total_irrigation_ms = 0;
    last_watering_cycle_ms = 0;
    last_moisture_level = 0.5f;
    
    return ESP_OK;
}

esp_err_t IrrigationController::init_pump_control() {
    gpio_config_t cfg{};
    cfg.mode = GPIO_MODE_OUTPUT;
    cfg.pin_bit_mask = (1ULL << 15);  // GPIO 15 for pump relay
    gpio_config(&cfg);
    gpio_set_level(GPIO_NUM_15, 0);  // Start with pump OFF
    return ESP_OK;
}

esp_err_t IrrigationController::init_manual_button() {
    gpio_config_t cfg{};
    cfg.mode = GPIO_MODE_INPUT;
    cfg.pull_up_en = GPIO_PULLUP_ENABLE;
    cfg.pin_bit_mask = (1ULL << 0);  // GPIO 0 for manual button
    gpio_config(&cfg);
    return ESP_OK;
}

void IrrigationController::update(const SensorReadings &readings, uint32_t soil_health_state) {
    uint32_t current_time_ms = esp_timer_get_time() / 1000;
    
    // Check manual trigger
    if (check_manual_trigger()) {
        ESP_LOGI(TAG, "Manual irrigation triggered");
        activate_pump();
    }
    
    // Check irrigation conditions
    bool should_water = false;
    
    // Automatic watering based on moisture
    if (readings.soil_moisture < (MOISTURE_THRESHOLD_LOW / 100.0f)) {
        should_water = true;
        ESP_LOGI(TAG, "Moisture low: %.1f%% < %d%%", readings.soil_moisture * 100, MOISTURE_THRESHOLD_LOW);
    }
    
    // Stop watering if moisture reaches high threshold
    if (readings.soil_moisture > (MOISTURE_THRESHOLD_HIGH / 100.0f)) {
        should_water = false;
        if (pump_state == WATERING) {
            ESP_LOGI(TAG, "Moisture adequate: %.1f%% >= %d%%", readings.soil_moisture * 100, MOISTURE_THRESHOLD_HIGH);
        }
    }
    
    // Check safety conditions
    if (!is_safe_to_water(readings)) {
        should_water = false;
    }
    
    // Update pump state
    if (pump_state == WATERING) {
        uint32_t watering_time = current_time_ms - pump_start_time_ms;
        if (watering_time > MAX_PUMP_DURATION) {
            ESP_LOGW(TAG, "Max pump duration exceeded: %lu ms", watering_time);
            deactivate_pump();
        } else if (!should_water) {
            deactivate_pump();
        }
    } else if (should_water && pump_state != BLOCKED) {
        activate_pump();
    }
}

void IrrigationController::activate_pump() {
    if (pump_state != WATERING) {
        pump_state = WATERING;
        pump_start_time_ms = esp_timer_get_time() / 1000;
        gpio_set_level(GPIO_NUM_15, 1);
        ESP_LOGI(TAG, "Pump ACTIVATED");
    }
}

void IrrigationController::deactivate_pump() {
    if (pump_state == WATERING) {
        uint32_t watering_duration = (esp_timer_get_time() / 1000) - pump_start_time_ms;
        total_irrigation_ms += watering_duration;
        last_watering_cycle_ms = esp_timer_get_time() / 1000;
        
        pump_state = IDLE;
        gpio_set_level(GPIO_NUM_15, 0);
        ESP_LOGI(TAG, "Pump DEACTIVATED - Duration: %lu ms, Total: %lu ms", 
                 watering_duration, total_irrigation_ms);
    }
}

bool IrrigationController::check_manual_trigger() {
    static uint32_t last_button_time = 0;
    uint32_t current_time = esp_timer_get_time() / 1000;
    
    if (gpio_get_level(GPIO_NUM_0) == 0) {  // Button pressed (active low)
        if (current_time - last_button_time > 100) {  // Debounce
            last_button_time = current_time;
            return true;
        }
    }
    return false;
}

bool IrrigationController::is_safe_to_water(const SensorReadings &readings) const {
    // Don't water if tank is empty
    if (readings.water_tank_level < 0.1f) {
        if (pump_state == WATERING) {
            ESP_LOGW(TAG, "Water tank too low: %.1f%%", readings.water_tank_level * 100);
        }
        return false;
    }
    
    // Don't water if soil is too wet (prevent waterlogging)
    if (readings.soil_moisture > 0.9f) {
        if (pump_state == WATERING) {
            ESP_LOGW(TAG, "Soil too wet: %.1f%% > 90%%", readings.soil_moisture * 100);
        }
        return false;
    }
    
    // Prevent pump from running during night (when light < 20%)
    if (readings.light_level < 0.2f && pump_state != WATERING) {
        return false;  // Don't start new cycles at night
    }
    
    return true;
}

bool IrrigationController::is_pump_active() const {
    return pump_state == WATERING;
}

uint32_t IrrigationController::get_total_irrigation_time() const {
    return total_irrigation_ms;
}
