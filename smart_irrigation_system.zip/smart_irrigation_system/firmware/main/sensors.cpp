#include "sensors.hpp"
#include "esp_log.h"
#include "driver/gpio.h"
#include "driver/adc.h"
#include "esp_adc_cal.h"

static const char *TAG = "SENSOR_HUB";

esp_err_t SensorHub::init() {
    ESP_LOGI(TAG, "Initializing sensor hub...");
    
    ESP_ERROR_CHECK(init_moisture_sensor());
    ESP_ERROR_CHECK(init_conductivity_sensor());
    ESP_ERROR_CHECK(init_temperature_sensors());
    ESP_ERROR_CHECK(init_humidity_sensor());
    ESP_ERROR_CHECK(init_light_sensor());
    ESP_ERROR_CHECK(init_water_level_sensor());
    
    ESP_LOGI(TAG, "Sensor hub initialized successfully");
    return ESP_OK;
}

esp_err_t SensorHub::init_moisture_sensor() {
    // Configure ADC for capacitive moisture sensor (GPIO 34)
    adc1_config_width(ADC_WIDTH_BIT_12);
    adc1_config_channel_atten(ADC1_CHANNEL_6, ADC_ATTEN_DB_11);
    return ESP_OK;
}

esp_err_t SensorHub::init_conductivity_sensor() {
    // Configure ADC for EC sensor (GPIO 35)
    adc1_config_channel_atten(ADC1_CHANNEL_7, ADC_ATTEN_DB_11);
    return ESP_OK;
}

esp_err_t SensorHub::init_temperature_sensors() {
    // Configure GPIO 13 for DS18B20 OneWire protocol
    // Would use OneWire library integration here
    return ESP_OK;
}

esp_err_t SensorHub::init_humidity_sensor() {
    // Configure GPIO 12 for DHT22
    // Would use DHT driver integration here
    return ESP_OK;
}

esp_err_t SensorHub::init_light_sensor() {
    // Configure I2C for BH1750 (SDA=21, SCL=22)
    // Would use I2C driver integration here
    return ESP_OK;
}

esp_err_t SensorHub::init_water_level_sensor() {
    // Configure GPIO 14 for float switch
    gpio_config_t cfg{};
    cfg.pin_bit_mask = (1ULL << 14);
    cfg.mode = GPIO_MODE_INPUT;
    cfg.pull_up_en = GPIO_PULLUP_ENABLE;
    return gpio_config(&cfg);
}

esp_err_t SensorHub::sample(SensorReadings &out_readings) {
    ESP_ERROR_CHECK(read_soil_moisture(out_readings.soil_moisture, out_readings.moisture_valid));
    ESP_ERROR_CHECK(read_conductivity(out_readings.soil_conductivity, out_readings.conductivity_valid));
    ESP_ERROR_CHECK(read_soil_temperature(out_readings.soil_temperature, out_readings.temperature_valid));
    ESP_ERROR_CHECK(read_ambient_temperature(out_readings.ambient_temperature, out_readings.humidity_valid));
    ESP_ERROR_CHECK(read_humidity(out_readings.ambient_humidity, out_readings.humidity_valid));
    ESP_ERROR_CHECK(read_light_level(out_readings.light_level, out_readings.light_valid));
    ESP_ERROR_CHECK(read_water_level(out_readings.water_tank_level, out_readings.tank_valid));
    
    out_readings.soil_health_score = calculate_soil_health(out_readings);
    
    return ESP_OK;
}

esp_err_t SensorHub::read_soil_moisture(float &moisture, bool &valid) {
    int adc_reading = adc1_get_raw(ADC1_CHANNEL_6);
    // Convert 0-4095 to 0-1 range, then to 0-100%
    moisture = clamp01(adc_reading / 4095.0f);
    valid = true;
    return ESP_OK;
}

esp_err_t SensorHub::read_conductivity(float &ec, bool &valid) {
    int adc_reading = adc1_get_raw(ADC1_CHANNEL_7);
    // Convert to EC value in mS/cm (typical 0-3.0 range)
    ec = (adc_reading / 4095.0f) * 3.0f;
    valid = true;
    return ESP_OK;
}

esp_err_t SensorHub::read_soil_temperature(float &temp, bool &valid) {
    // Placeholder: Would read from DS18B20
    temp = 24.5f;  // Simulated
    valid = true;
    return ESP_OK;
}

esp_err_t SensorHub::read_ambient_temperature(float &temp, bool &valid) {
    // Placeholder: Would read from DHT22
    temp = 22.0f;  // Simulated
    valid = true;
    return ESP_OK;
}

esp_err_t SensorHub::read_humidity(float &humidity, bool &valid) {
    // Placeholder: Would read from DHT22
    humidity = 65.0f;  // Simulated
    valid = true;
    return ESP_OK;
}

esp_err_t SensorHub::read_light_level(float &level, bool &valid) {
    // Placeholder: Would read from BH1750 via I2C
    level = 0.7f;  // Simulated (0-1 range)
    valid = true;
    return ESP_OK;
}

esp_err_t SensorHub::read_water_level(float &level, bool &valid) {
    bool tank_full = gpio_get_level(GPIO_NUM_14) == 1;
    level = tank_full ? 1.0f : 0.5f;  // Simplified
    valid = true;
    return ESP_OK;
}

float SensorHub::clamp01(float value) const {
    return value < 0.0f ? 0.0f : (value > 1.0f ? 1.0f : value);
}

float SensorHub::calculate_soil_health(const SensorReadings &readings) const {
    // Weighted health score based on soil conditions
    float health = 1.0f;
    
    // Moisture component (optimal: 60-75%)
    float moisture_score = 1.0f;
    if (readings.soil_moisture < 0.50f) moisture_score = 0.5f;  // Too dry
    else if (readings.soil_moisture < 0.60f) moisture_score = 0.8f;  // Slightly dry
    else if (readings.soil_moisture > 0.85f) moisture_score = 0.7f;  // Too wet
    
    // EC component (optimal: 0.8-2.0 mS/cm)
    float ec_score = 1.0f;
    if (readings.soil_conductivity < 0.3f) ec_score = 0.6f;  // Too low nutrients
    else if (readings.soil_conductivity > 2.5f) ec_score = 0.6f;  // Too high salinity
    
    // Temperature component (optimal: 20-28°C)
    float temp_score = 1.0f;
    if (readings.soil_temperature < 15.0f) temp_score = 0.7f;
    else if (readings.soil_temperature > 32.0f) temp_score = 0.7f;
    
    health = (moisture_score * 0.5f) + (ec_score * 0.3f) + (temp_score * 0.2f);
    return clamp01(health);
}
