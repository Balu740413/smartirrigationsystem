#pragma once

#include <array>
#include <cstdint>

#include "esp_err.h"

struct SensorReadings {
    float soil_moisture;           // Soil moisture level (0-1, 0-100%)
    float soil_conductivity;       // EC sensor reading (mS/cm)
    float soil_temperature;        // Soil temperature (°C)
    float ambient_temperature;     // Air temperature (°C)
    float ambient_humidity;        // Air humidity (%)
    float light_level;             // Light intensity (0-1, 0=dark, 1=bright)
    float water_tank_level;        // Water tank level (0-1, 0-100%)
    float irrigation_duration;     // Current irrigation pulse duration (ms)
    float soil_health_score;       // Overall soil health (0-1, higher = healthier)
    bool moisture_valid;
    bool conductivity_valid;
    bool temperature_valid;
    bool humidity_valid;
    bool light_valid;
    bool tank_valid;
};

class SensorHub {
public:
    esp_err_t init();
    esp_err_t sample(SensorReadings &out_readings);

private:
    esp_err_t init_moisture_sensor();
    esp_err_t init_conductivity_sensor();
    esp_err_t init_temperature_sensors();
    esp_err_t init_humidity_sensor();
    esp_err_t init_light_sensor();
    esp_err_t init_water_level_sensor();

    esp_err_t read_soil_moisture(float &moisture, bool &valid);
    esp_err_t read_conductivity(float &ec, bool &valid);
    esp_err_t read_soil_temperature(float &temp, bool &valid);
    esp_err_t read_ambient_temperature(float &temp, bool &valid);
    esp_err_t read_humidity(float &humidity, bool &valid);
    esp_err_t read_light_level(float &level, bool &valid);
    esp_err_t read_water_level(float &level, bool &valid);
    
    float clamp01(float value) const;
    float calculate_soil_health(const SensorReadings &readings) const;
};
