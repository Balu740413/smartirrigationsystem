#include "ai_processor.hpp"
#include "esp_log.h"
#include "esp_timer.h"
#include "tensorflow/lite/micro/kernels/all_ops_resolver.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/schema/schema_generated.h"

static const char *TAG = "AI_PROCESSOR";
extern const unsigned char ai_model_data[];
extern const unsigned int ai_model_data_len;

namespace {
constexpr int kTensorArenaSize = 10 * 1024;
uint8_t tensor_arena[kTensorArenaSize];

tflite::MicroInterpreter *interpreter = nullptr;
TfLiteTensor *input_tensor = nullptr;
TfLiteTensor *output_tensor = nullptr;
}

esp_err_t AiProcessor::init() {
    ESP_LOGI(TAG, "Initializing AI processor with TensorFlow Lite Micro...");
    
    // Load model
    const tflite::Model *model = tflite::GetModel(ai_model_data);
    if (model->version() != TFLITE_SCHEMA_VERSION) {
        ESP_LOGE(TAG, "Model version mismatch!");
        return ESP_FAIL;
    }
    
    // Setup resolver
    static tflite::AllOpsResolver resolver;
    
    // Create interpreter
    static tflite::MicroInterpreter static_interpreter(model, resolver, tensor_arena, kTensorArenaSize);
    interpreter = &static_interpreter;
    
    if (interpreter->AllocateTensors() != kTfLiteOk) {
        ESP_LOGE(TAG, "AllocateTensors() failed");
        return ESP_FAIL;
    }
    
    input_tensor = interpreter->input(0);
    output_tensor = interpreter->output(0);
    
    ESP_LOGI(TAG, "AI processor initialized successfully");
    ESP_LOGI(TAG, "Input shape: [%d, %d], Output shape: [%d]", 
             input_tensor->dims->data[0], input_tensor->dims->data[1],
             output_tensor->dims->data[0]);
    
    return ESP_OK;
}

esp_err_t AiProcessor::infer(const FeatureVector &features, InferenceResult &out_result) {
    int64_t start_time = esp_timer_get_time();
    
    // Copy features to input tensor
    float *input_data = input_tensor->data.f;
    for (size_t i = 0; i < 18; i++) {
        input_data[i] = features.data[i];
    }
    
    // Run inference
    if (interpreter->Invoke() != kTfLiteOk) {
        ESP_LOGE(TAG, "Invoke failed");
        return ESP_FAIL;
    }
    
    // Extract output
    float *output_data = output_tensor->data.f;
    for (size_t i = 0; i < 4; i++) {
        out_result.class_scores[i] = output_data[i];
    }
    
    // Get predicted class (highest score)
    out_result.predicted_class = 0;
    out_result.confidence = output_data[0];
    for (size_t i = 1; i < 4; i++) {
        if (output_data[i] > out_result.confidence) {
            out_result.predicted_class = i;
            out_result.confidence = output_data[i];
        }
    }
    
    out_result.inference_time_ms = (esp_timer_get_time() - start_time) / 1000;
    
    log_inference_result(out_result);
    return ESP_OK;
}

void AiProcessor::log_inference_result(const InferenceResult &result) {
    const char *state_names[] = {"OPTIMAL", "GOOD", "NEEDS_WATER", "CRITICAL"};
    ESP_LOGI(TAG, "Classification: %s (%.2f%%) | Time: %lu ms",
             state_names[result.predicted_class],
             result.confidence * 100.0f,
             result.inference_time_ms);
    ESP_LOGI(TAG, "Scores: [%.3f, %.3f, %.3f, %.3f]",
             result.class_scores[0], result.class_scores[1],
             result.class_scores[2], result.class_scores[3]);
}

void AiProcessor::softmax(float *logits, float *output, size_t size) {
    float max = logits[0];
    for (size_t i = 1; i < size; i++) {
        if (logits[i] > max) max = logits[i];
    }
    
    float sum = 0.0f;
    for (size_t i = 0; i < size; i++) {
        output[i] = expf(logits[i] - max);
        sum += output[i];
    }
    
    for (size_t i = 0; i < size; i++) {
        output[i] /= sum;
    }
}
