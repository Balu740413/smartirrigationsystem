#!/usr/bin/env python3
"""
Train TensorFlow Lite Micro model for soil health classification
Smart Irrigation and Soil Health Monitoring System

This script generates a synthetic dataset and trains a 4-class classifier:
- Class 0: Optimal (ideal growing conditions)
- Class 1: Good (acceptable conditions)
- Class 2: Needs Water (irrigation required)
- Class 3: Critical (emergency intervention needed)

Input features (18):
1-8: Raw sensor values (moisture, EC, soil temp, air temp, humidity, light, tank level, health score)
9-13: Rolling averages (moisture, EC, temp, moisture trend, EC trend)
14-18: Stress indicators (drought, waterlogging, nutrient, temperature, light stress)
"""

import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import struct

# Configuration
SEED = 42
NUM_SAMPLES = 5000
FEATURE_DIM = 18
NUM_CLASSES = 4
TEST_SPLIT = 0.2
VALIDATION_SPLIT = 0.2

# Thresholds for classification
MOISTURE_LOW = 45.0  # % - start irrigation
MOISTURE_HIGH = 75.0  # % - stop irrigation
EC_OPTIMAL_MIN = 0.8  # mS/cm
EC_OPTIMAL_MAX = 2.0
TEMP_OPTIMAL_MIN = 20.0  # °C
TEMP_OPTIMAL_MAX = 28.0

def generate_synthetic_data(num_samples):
    """Generate synthetic training data with realistic distributions."""
    print(f"Generating {num_samples} synthetic samples...")
    
    X = np.zeros((num_samples, FEATURE_DIM), dtype=np.float32)
    y = np.zeros(num_samples, dtype=np.int32)
    
    for i in range(num_samples):
        # Generate random class (balanced distribution)
        class_idx = np.random.randint(0, NUM_CLASSES)
        
        if class_idx == 0:  # Optimal
            moisture = np.random.normal(67.5, 5)  # 60-75%
            ec = np.random.normal(1.4, 0.3)  # 0.8-2.0 mS/cm
            soil_temp = np.random.normal(24, 3)  # 20-28°C
            air_temp = soil_temp - np.random.normal(2, 0.5)
            humidity = np.random.normal(65, 8)
            light = np.random.normal(75, 15)
            tank_level = np.random.normal(90, 10)
            stress = np.random.normal(0.1, 0.05, 5)  # Low stress
            
        elif class_idx == 1:  # Good
            moisture = np.random.normal(65, 8)  # 50-80%
            ec = np.random.normal(1.2, 0.5)  # Wider range
            soil_temp = np.random.normal(22, 4)
            air_temp = soil_temp - np.random.normal(2, 0.5)
            humidity = np.random.normal(60, 10)
            light = np.random.normal(60, 20)
            tank_level = np.random.normal(75, 15)
            stress = np.random.normal(0.25, 0.1, 5)  # Moderate stress
            
        elif class_idx == 2:  # Needs Water
            moisture = np.random.normal(40, 8)  # <50% - water stress
            ec = np.random.normal(1.5, 0.6)  # High EC stress
            soil_temp = np.random.normal(26, 4)  # Can be hot
            air_temp = soil_temp - np.random.normal(2, 0.5)
            humidity = np.random.normal(50, 12)  # Lower humidity
            light = np.random.normal(70, 15)
            tank_level = np.random.normal(50, 20)  # Lower water
            stress = np.random.normal(0.6, 0.15, 5)  # High stress
            
        else:  # Critical (class 3)
            moisture = np.random.normal(25, 8)  # <30% - severe drought
            ec_val = np.random.choice([np.random.normal(0.15, 0.1), np.random.normal(3.2, 0.3)])  # Imbalanced
            ec = np.clip(ec_val, 0.05, 3.5)
            soil_temp = np.random.choice([
                np.random.normal(8, 2),  # Too cold
                np.random.normal(35, 2)  # Too hot
            ])
            air_temp = soil_temp - np.random.normal(2, 0.5)
            humidity = np.random.choice([
                np.random.normal(25, 5),  # Too dry
                np.random.normal(90, 3)  # Too wet
            ])
            light = np.random.normal(40, 25)  # Variable
            tank_level = np.random.normal(15, 10)  # Very low
            stress = np.random.normal(0.85, 0.1, 5)  # Severe stress
        
        # Clamp values to realistic ranges
        moisture = np.clip(moisture, 20, 95)
        ec = np.clip(ec, 0.1, 3.5)
        soil_temp = np.clip(soil_temp, 5, 40)
        air_temp = np.clip(air_temp, 5, 40)
        humidity = np.clip(humidity, 20, 95)
        light = np.clip(light, 0, 100)
        tank_level = np.clip(tank_level, 0, 100)
        stress = np.clip(stress, 0, 1)
        
        # Build feature vector
        X[i, 0] = moisture / 100.0  # Normalize to 0-1
        X[i, 1] = ec / 3.5  # Normalize
        X[i, 2] = soil_temp / 50.0
        X[i, 3] = air_temp / 50.0
        X[i, 4] = humidity / 100.0
        X[i, 5] = light / 100.0
        X[i, 6] = tank_level / 100.0
        X[i, 7] = 1.0 - (stress[0] + stress[1]) / 2  # Health score
        
        # Rolling averages
        X[i, 8] = X[i, 0]  # Moisture avg
        X[i, 9] = X[i, 1]  # EC avg
        X[i, 10] = X[i, 2]  # Temp avg
        X[i, 11] = np.random.normal(0, 0.1)  # Moisture trend
        X[i, 12] = np.random.normal(0, 0.05)  # EC trend
        
        # Stress indicators
        X[i, 13:18] = stress
        
        y[i] = class_idx
    
    return X, y

def build_model(input_dim, num_classes):
    """Build TensorFlow Lite compatible model."""
    print("Building model...")
    
    model = keras.Sequential([
        layers.Dense(64, activation='relu', input_shape=(input_dim,)),
        layers.Dropout(0.3),
        layers.Dense(32, activation='relu'),
        layers.Dropout(0.2),
        layers.Dense(16, activation='relu'),
        layers.Dense(num_classes, activation='softmax')
    ])
    
    model.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model

def train_model(X_train, y_train, X_val, y_val):
    """Train the model."""
    model = build_model(X_train.shape[1], NUM_CLASSES)
    
    print("\nTraining model...")
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=100,
        batch_size=32,
        verbose=1,
        callbacks=[
            keras.callbacks.EarlyStopping(
                monitor='val_loss',
                patience=10,
                restore_best_weights=True
            )
        ]
    )
    
    return model, history

def convert_to_tflite(model, X_train):
    """Convert Keras model to TensorFlow Lite format."""
    print("\nConverting model to TensorFlow Lite...")
    
    # Quantize to INT8 for edge deployment
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    converter.target_spec.supported_ops = [
        tf.lite.OpsSet.TFLITE_BUILTINS_INT8
    ]
    converter.inference_input_type = tf.int8
    converter.inference_output_type = tf.int8
    
    # Use representative dataset for quantization calibration
    def representative_data_gen():
        for i in range(min(100, len(X_train))):
            yield [X_train[i:i+1].astype(np.float32)]
    
    converter.representative_dataset = representative_data_gen
    
    tflite_model = converter.convert()
    return tflite_model

def save_model_data(tflite_model, output_dir='artifacts'):
    """Save TFLite model as C++ header file for ESP32."""
    os.makedirs(output_dir, exist_ok=True)
    
    # Save as .tflite file for ML backend server
    tflite_file = os.path.join(output_dir, 'guardian_model.tflite')
    with open(tflite_file, 'wb') as f:
        f.write(tflite_model)
    print(f"TFLite model saved: {tflite_file} ({len(tflite_model)} bytes)")
    
    # Also save as binary file (for backward compatibility)
    binary_file = os.path.join(output_dir, 'ai_model_data.bin')
    with open(binary_file, 'wb') as f:
        f.write(tflite_model)
    print(f"Binary model saved: {binary_file} ({len(tflite_model)} bytes)")
    
    # Generate C++ header
    cpp_file = os.path.join(output_dir, 'ai_model_data.cc')
    with open(cpp_file, 'w') as f:
        f.write("#include <cstdint>\n\n")
        f.write("// AI Model Data for Soil Health Classification\n")
        f.write(f"// Generated model size: {len(tflite_model)} bytes\n")
        f.write(f"// Input: 18 features (soil moisture, EC, temperature, etc.)\n")
        f.write(f"// Output: 4 classes (Optimal, Good, Needs Water, Critical)\n\n")
        
        f.write("alignas(8) const unsigned char ai_model_data[] = {\n")
        
        # Write hex data
        for i, byte in enumerate(tflite_model):
            if i % 12 == 0:
                f.write("    ")
            f.write(f"0x{byte:02x}")
            if i < len(tflite_model) - 1:
                f.write(", ")
            if (i + 1) % 12 == 0:
                f.write("\n")
        
        if len(tflite_model) % 12 != 0:
            f.write("\n")
        
        f.write("};\n\n")
        f.write(f"const unsigned int ai_model_data_len = {len(tflite_model)};\n")
    
    print(f"C++ header generated: {cpp_file}")
    
    # Generate H++ header
    h_file = os.path.join(output_dir, 'ai_model_data.h')
    with open(h_file, 'w') as f:
        f.write("#pragma once\n\n")
        f.write("extern const unsigned char ai_model_data[];\n")
        f.write("extern const unsigned int ai_model_data_len;\n")
    
    print(f"Header file generated: {h_file}")

def evaluate_model(model, X_test, y_test):
    """Evaluate model on test set."""
    print("\nEvaluating model...")
    loss, accuracy = model.evaluate(X_test, y_test, verbose=0)
    print(f"Test Loss: {loss:.4f}")
    print(f"Test Accuracy: {accuracy:.4f}")
    
    # Per-class metrics
    predictions = model.predict(X_test, verbose=0)
    predicted_classes = np.argmax(predictions, axis=1)
    
    class_names = ['Optimal', 'Good', 'Needs Water', 'Critical']
    for i in range(NUM_CLASSES):
        mask = y_test == i
        if mask.sum() > 0:
            class_acc = (predicted_classes[mask] == i).mean()
            print(f"  {class_names[i]}: {class_acc:.4f}")

def main():
    """Main training pipeline."""
    print("=" * 60)
    print("Soil Health Classification Model Training")
    print("=" * 60)
    
    # Generate synthetic data
    X, y = generate_synthetic_data(NUM_SAMPLES)
    
    # Split data
    split_idx = int(NUM_SAMPLES * (1 - TEST_SPLIT))
    val_idx = int(split_idx * (1 - VALIDATION_SPLIT))
    
    X_train = X[:val_idx]
    y_train = y[:val_idx]
    X_val = X[val_idx:split_idx]
    y_val = y[val_idx:split_idx]
    X_test = X[split_idx:]
    y_test = y[split_idx:]
    
    print(f"\nDataset split:")
    print(f"  Training: {len(X_train)} samples")
    print(f"  Validation: {len(X_val)} samples")
    print(f"  Testing: {len(X_test)} samples")
    
    # Train model
    model, history = train_model(X_train, y_train, X_val, y_val)
    
    # Evaluate
    evaluate_model(model, X_test, y_test)
    
    # Convert to TFLite
    tflite_model = convert_to_tflite(model, X_train)
    
    # Save outputs
    save_model_data(tflite_model)
    
    print("\n" + "=" * 60)
    print("Training complete!")
    print("Next steps:")
    print("1. Copy artifacts/ai_model_data.cc to firmware/main/")
    print("2. Copy artifacts/ai_model_data.h to firmware/main/")
    print("3. Build firmware with: idf.py build flash monitor")
    print("=" * 60)

if __name__ == '__main__':
    main()
