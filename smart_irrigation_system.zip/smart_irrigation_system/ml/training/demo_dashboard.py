#!/usr/bin/env python3
"""
Web Dashboard Demo for Smart Irrigation System
Generates real-time sensor data and displays it via a local web server

This is an alternative to opening index.html directly - provides dynamic data generation
"""

from http.server import HTTPServer, SimpleHTTPRequestHandler
from threading import Thread
import json
import math
import time
from datetime import datetime
from pathlib import Path

# Simulation state
class IrrigationSimulator:
    def __init__(self):
        self.moisture = 65.0
        self.ec = 1.2
        self.soil_temp = 24.5
        self.air_temp = 22.0
        self.humidity = 65.0
        self.light = 70.0
        self.tank_level = 95.0
        self.pump_active = False
        self.pump_start_time = 0
        self.total_irrigation_ms = 0
        self.last_update = time.time()
        self.event_log = []
        self.moisture_history = []
        
        self.add_event("System initialized")
        self.add_event("Sensor simulation started")
    
    def add_event(self, msg):
        timestamp = datetime.now().strftime("%H:%M:%S")
        event = f"[{timestamp}] {msg}"
        self.event_log.insert(0, event)
        if len(self.event_log) > 50:
            self.event_log.pop()
    
    def update(self):
        """Update simulation state"""
        now = time.time()
        delta_sec = now - self.last_update
        self.last_update = now
        
        # Simulate daily cycle (accelerated)
        seconds_since_start = (now % 86400)  # Seconds in a day
        hour = (seconds_since_start / 3600) * 6  # Accelerated 6x
        
        # Temperature cycle
        air_temp = 18 + 10 * math.sin(math.pi * (hour - 6) / 12)
        self.air_temp = round(air_temp, 1)
        self.soil_temp = round(self.air_temp + 2, 1)
        
        # Humidity (inverse to temperature)
        self.humidity = round(70 - 20 * math.sin(math.pi * (hour - 6) / 12), 1)
        self.humidity = max(30, min(95, self.humidity))
        
        # Light cycle
        if hour < 6 or hour > 18:
            self.light = 0
        else:
            self.light = round(100 * math.sin(math.pi * (hour - 6) / 12), 0)
        
        # Moisture decreases due to evapotranspiration
        evaporation = (0.5 + self.light / 100) * delta_sec / 20
        self.moisture -= evaporation
        
        # Pump control
        if not self.pump_active and self.moisture < 45:
            self.pump_active = True
            self.pump_start_time = now
            self.add_event("Pump ACTIVATED - Watering cycle started")
        
        if self.pump_active:
            self.moisture += 0.3 * delta_sec
            self.tank_level -= 0.15 * delta_sec
        
        if self.pump_active and self.moisture >= 75:
            duration = (now - self.pump_start_time) * 1000
            self.total_irrigation_ms += duration
            self.pump_active = False
            self.add_event(f"Pump DEACTIVATED - Duration: {int(duration)}ms")
        
        # Clamp values
        self.moisture = max(20, min(95, self.moisture))
        self.ec = 1.2 + (hash(int(now)) % 100 - 50) / 1000
        self.tank_level = max(0, self.tank_level)
        
        # Slow refill
        if self.tank_level < 20:
            self.tank_level += 0.1 * delta_sec
        
        # Update history
        self.moisture_history.append(self.moisture)
        if len(self.moisture_history) > 100:
            self.moisture_history.pop(0)
    
    def get_state(self):
        """Get current state as JSON"""
        # Classify health
        classification = 0
        if self.moisture < 45:
            classification = 3
        elif self.moisture < 60:
            classification = 2
        elif self.moisture > 85 or self.ec < 0.3 or self.ec > 2.5:
            classification = 1
        
        class_names = ['Optimal', 'Good', 'Needs Water', 'Critical']
        
        return {
            'moisture': round(self.moisture, 1),
            'ec': round(self.ec, 2),
            'soil_temp': self.soil_temp,
            'air_temp': self.air_temp,
            'humidity': self.humidity,
            'light': self.light,
            'tank_level': round(self.tank_level, 1),
            'pump_active': self.pump_active,
            'total_irrigation_min': round(self.total_irrigation_ms / 60000, 1),
            'health_state': class_names[classification],
            'confidence': 0.87,
            'events': self.event_log[:15]
        }

# Global simulator instance
simulator = IrrigationSimulator()

class DashboardHandler(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/api/state':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            simulator.update()
            state_json = json.dumps(simulator.get_state())
            self.wfile.write(state_json.encode())
        else:
            # Serve static files
            super().do_GET()
    
    def log_message(self, format, *args):
        print(f"[{datetime.now().strftime('%H:%M:%S')}] {format % args}")

def run_server(port=8000):
    """Run the dashboard web server"""
    server_address = ('', port)
    httpd = HTTPServer(server_address, DashboardHandler)
    print(f"\nDashboard server running at http://localhost:{port}")
    print("Press Ctrl+C to stop")
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped")
        httpd.server_close()

if __name__ == '__main__':
    import sys
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    
    print("=" * 60)
    print("Smart Irrigation Dashboard - Web Server")
    print("=" * 60)
    
    # Change to script directory for serving static files
    script_dir = Path(__file__).parent.parent / 'demo_dashboard_web'
    if script_dir.exists():
        import os
        os.chdir(script_dir)
        print(f"Serving from: {script_dir}")
    else:
        print(f"Warning: Dashboard directory not found at {script_dir}")
    
    run_server(port)
